<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class processing extends Controller
{
    //
    public function process(Request $request)
    {
      $json=$request->get('data');
      $param=$request->get('param');
      $coms=array();
      $verif=array();
      //param = [0.3,0.5,0.03,0.03,3,1000];
      /*
      $param
       array entries  : 0 ---> comission fee for private account on withdraw transactions
                        1 ---> comission fee for business account on withdraw transactions
                        2 ---> comission fee for private account on deposit transactions
                        3 ---> comission fee for business account on deposit transactions
                        4 ---> number of free transaction under an amount per week
                        5 ---> the threshold of amount
                 */
      foreach($json as $line)
      {
        if($line[3]=='deposit')
        {
          // deposit operation
          $val1=$param[2]/100;
          if($line[2]=='business')
          {$val1=$param[3]/100;}

          array_push($coms,round($line[4]*$val1,2));
        }
        else {
          // withdraw operation

          if($line[2]=='business')
          {
            // business account
            array_push($coms,round($line[4]*($param[1]/100),2));
          }
          else {
            // private account

            //check json
            if(array_key_exists($line[6].$line[7], $verif))
            {


              if(array_key_exists($line[1], $verif[$line[6].$line[7]]))
              {
                //  new withdraw for existing week key and existing user key

                $mpr=0;

                $tit=$verif[$line[6].$line[7]][$line[1]][1];
                //check the number of the operations per week
                if($param[4]>0 && $tit<=$param[4])
                {

                  if(($verif[$line[6].$line[7]][$line[1]][0])>=$param[5])
                  {
                    $mpr=$line[4]*($param[0]/100);
                  }else {

                    if(($verif[$line[6].$line[7]][$line[1]][0]+$line[4])>$param[5])
                    {
                      $tota=$verif[$line[6].$line[7]][$line[1]][0]+$line[4];
                      $mpr=($tota-$param[5])*($param[0]/100);
                    }
                  }

                }
                else {
                  // number of operation exceeded three times
                  $mpr=$line[4]*($param[0]/100);
                  // code...
                }
                $tit+=1;
                $verif[$line[6].$line[7]][$line[1]][1]=$tit;

                $verif[$line[6].$line[7]][$line[1]][0]=$verif[$line[6].$line[7]][$line[1]][0]+$line[4];

              }
              else {
                //  new withdraw for a new user key at existing week key
                $verif[$line[6].$line[7]][$line[1]]=array($line[4],1);
                $mpr=0;
                if($line[4]>$param[5])
                {
                  $mpr=($line[4])*($param[0]/100);
                }

              }

            }
            else {
              //  new withdraw for a new week key and a new user key
              $verif[$line[6].$line[7]]=array();
              $verif[$line[6].$line[7]][$line[1]]=array($line[4],1);
              $mpr=0;
              if($line[4]>$param[5])
              {
                $mpr=($line[4]-$param[5])*($param[0]/100);
              }

            }

            array_push($coms,round($mpr,2));
          }
        }
      }

      return response()->json(array('act'=>$coms), 200);

    }
}
