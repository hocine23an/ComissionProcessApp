<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Process Application</title>


  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<style>
.center {
  margin: auto;
  width: 60%;

  padding: 10px;
width:100%;
min-height:calc(100vh) !important;
max-width:1400px;
}
.conta {

  position: relative;
padding:0px;
max-width:200px;
}
.conta button{

}
.vertical-center {
  margin: auto;

}
</style>

</head>
<body>
  <div class="modal fade" data-toggle="modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"></h5>

      </div>
      <div class="modal-body" style="height:calc(70vh);overflow:auto">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary closo" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary solva" disabled="true">Save changes</button>
      </div>
    </div>
  </div>
  </div>

<div class="center">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#" style="margin-left:5px;font-size:160%">Process Application</a>
</nav>

<div class="card-group" style="min-height:calc(80vh) !important;">
  <div class="card">

    <div class="btn-group" role="group" aria-label="Basic example">
      <button type="button" class="btn btn-primary loadcsv">Load CSV File</button>
      <button type="button" class="btn btn-info currency">Currency exchange rate / €</button>
      <button type="button" class="btn btn-success settings">Comissions Settings</button>
      <input id="csv" type="file" style="display:none">
    </div>

    <div id="out" class="card-body" style="text-align:center;border:1px solid rgb(220,220,220);height:calc(80vh);overflow:auto">


    </div>
  </div>
  <div class="card conta cardi" style="display:none">


<div class="btn-group vertical-center " role="group" aria-label="Button group with nested dropdown">
  <button type="button" class="btn btn-primary comcalc" style="border-right:1px solid white !important">Commission processing >></button>

  <div class="btn-group" role="group" style="border-left:1px solid white">
    <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle dropda0" data-bs-toggle="dropdown" aria-expanded="false">
      EUR
    </button>
    <ul class="dropdown-menu dropda" aria-labelledby="btnGroupDrop1" style="max-height:200px;overflow:auto">

    </ul>
  </div>
</div>


  </div>
  <div class="card cardi" style="display:none">

      <button type="button" class="btn btn-success export" style="display:none">Export CSV File</button>

    <div class="card-body outt" style="border:1px solid rgb(220,220,220)">
<div class="load" style="display:none">Loading ...</div>
    </div>
  </div>
</div>



</div>
<input type="hidden" class="csrf" value="{{ csrf_token() }}">

<script>







$( document ).ready( function() {

  pattern = /^\d+(\.){1}$/;
  pattern2 = /^(\.){1}$/;
  pattern3 = /^(\.){1}\d+$/;
  pattern4 = /^(\.){1}[0]+$/;

  window.param=[0.3,0.5,0.03,0.03,3,1000];
  /*
  window.param
   array entries  : 0 ---> comission fee for private account on withdraw transactions
                    1 ---> comission fee for business account on withdraw transactions
                    2 ---> comission fee for private account on deposit transactions
                    3 ---> comission fee for business account on deposit transactions
                    4 ---> number of free transaction under an amount per week
                    5 ---> the threshold of amount
             */

// "Read file CSV" button Function
  var fileInput = document.getElementById("csv");
  var pimp,divo,adol,newDiv,htmlo,json;
  readFile = function () {
    document.getElementById("out").innerText='Loading ...';
      var reader = new FileReader();
      reader.onload = function () {


          pimp=reader.result.split("\n");

          htmlo='';
          window.result=[];
          for(var i=0;i<pimp.length;i++)
          {
            window.result[i]=[];
          adol=pimp[i].split(',');

            for(var j=0;j<adol.length;j++)
            {
              window.result[i].push(adol[j]);
            }
          }

          //order lines of JSON data by date ASC
          window.result.sort(function (a, b) {
              return new Date(a[0]).getTime() - new Date(b[0]).getTime();
          });
          // built table of data
          /**********************************/
          for(var i=0;i<window.result.length;i++)
          {
           newDiv = '';
            for(var j=0;j<window.result[i].length;j++)
            {
              newDiv+='<td>'+window.result[i][j]+'</td>';
            }
            htmlo+='<tr>'+newDiv+'</tr>';
          }
          /***********************************/

          document.getElementById("out").innerHTML='<table class="table">'+htmlo+'</table>';

          $('.cardi').show();



      };
      // start reading the file. When it is done, calls the onload event defined above.
      reader.readAsBinaryString(fileInput.files[0]);
  };




// convert day order function
  function convertime(x)
  {
    if(x==0)
    {
      return 6;
    }else {
      return x-1;
    }
  }
// function to Get first and last day of a date

  function affday(v,x)
  {
    m=0;
    if(v=='last')
    {m=6;  }
    datm=new Date(x);
    return new Date(datm.setDate(datm.getDate() - convertime(datm.getDay())+m)).getTime();
  }

fileInput.addEventListener('change', readFile);


// load csv file (the table data should be formatted as exemple)
  $('.loadcsv').click(function(){

    $('#csv').click();
  });

// function of select box to change currency of comission fees
function currchoice(v,h)
{
  $('.dropda0').html(v);
  $('.dropda').html('');

  for (var x in window.curr) {
    if(v!=x)
  {
  $('.dropda').append('<li ><a class="dropdown-item dropda1" href="#" val="'+x+'">'+x+'</a></li>');
  }
  }
  $('.dropda1').attr('vrd',h);
  // c
  $('.dropda1').off('click').on('click',function(){currchoice($(this).attr('val'),'1');if($(this).attr('vrd')=='1'){$('.comcalc').click();}});
}



// Read currency exchange rate JSON from URL
/************************/
$.getJSON('https://developers.paysera.com/tasks/api/currency-exchange-rates', function(data) {
window.curr=data.rates;
currchoice('EUR','0');

    });
    /**********************/

// return html content
function rethtml(x,y,z,html,marg)
{
  return '<h5 class="card-title" style="margin-top:'+marg+'px">'+x+'</h5>\
    <div class="card-body" style="border-left:2px solid rgb(220,220,220)">\
    <div class="input-group mb-3" style="width:250px">\
      <input type="text" class="form-control kkc" vh="'+y+'" name="'+y+'" value="'+z+'" placeholder="Commission" aria-label="Username" aria-describedby="basic-addon1">\
    <span class="input-group-text" id="basic-addon1">%</span>\
    </div>'+html+'</div>';
}

//  on keypress function , used for an amount input
function keypressfunc(e,ths)
{
  var unicode = e.charCode ? e.charCode : e.keyCode;


if((unicode==46 && ths.value=='') || (unicode==46 && ths.value.includes('.')))
{
  return false;
}
else {
     if( unicode != 8 )
     {
         if(unicode < 9 || unicode > 9 && unicode < 46 || unicode > 57 || unicode == 47) {
             if(unicode == 37 || unicode == 38) {
                 return true;

             }
             else {
                 return false;
             }
         }
         else {
             return true;

         }
     }
     else
     {
         return true;

     }
   }
}

// "Comissions Settings" Button

$('.settings').click(function(){

  $('.modal .modal-title').html('Comissions Settings');

  $('.modal .modal-body').html('<ul class="nav nav-tabs" id="myTab" role="tablist">\
  <li class="nav-item" role="presentation">\
    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Withdraw</button>\
  </li>\
  <li class="nav-item" role="presentation">\
    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Deposit</button>\
  </li>\
</ul>\
<div class="tab-content" id="myTabContent"><div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">\
'+rethtml('Private account',0,window.param[0],'<h6 class="card-subtitle mb-2 text-muted">Free transactions</h6>\
    <div class="input-group mb-3" style="width:600px">\
  <div class="input-group-text">Times \
  </div>\
  <input type="text" class="form-control wpnb kkc" placeholder="Times" vh="4" value="'+window.param[4]+'" name="wpnb">\
  <span class="input-group-text" id="basic-addon1">For &nbsp;<b> Total <= </b> </span>\
  <input type="text" class="form-control wptot kkc" placeholder="Amount" vh="5" value="'+window.param[5]+'" name="wptot">\
  <span class="input-group-text" id="basic-addon1">EUR </span></div>',30)+rethtml('Business account',1,window.param[1],'',0)+'</div>\
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">\
'+rethtml('Private account',2,window.param[2],'',30)+rethtml('Business account',3,window.param[3],'',0)+'</div>\
</div>');

  $('.modal').modal('show');



$('input.kkc').off('keypress').on('keypress', function(e){if(keypressfunc(e,this)==false){return false}});
$('input.kkc').on('input', function(e){$('.solva').prop('disabled',false);});



$('.solva').off('click').on('click',function(){

piko=0;
$('input.kkc').removeClass('is-invalid');
 $('input.kkc').each(function(index){


  if(!$(this).val() || pattern.test($(this).val()) || pattern2.test($(this).val()) || pattern3.test($(this).val()) || pattern4.test($(this).val()))
   {
     $(this).addClass('is-invalid');


   }else {piko+=1;
     window.param[$(this).attr('vh')]=parseFloat($(this).val());
   }
 });
 if(piko==6)
 {
  $('.modal').modal('hide');
}else {
  alert('Please check input value');
}

//.kkc
});

});

// "Currency exchange rate" button on click function

$('.currency').click(function(){

  $('.modal .modal-title').html('Currency exchange rate');
  $('.modal .modal-body').html('<table class="curtab table"><thead><tr><th></th><th><div class="dropdown">\
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="margin-bottom:10px">\
    Add New Currency\
  </button>\
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1" style="padding:10px;text-align:center">\
  <div class="input-group mb-3" style="width:250px">\
  <span class="input-group-text" id="basic-addon1">Currency</span>\
    <input type="text" class="form-control namcur alpcur" placeholder="Ex : EUR" onkeydown="return /[a-z]/i.test(event.key)" >\
  </div>\
  <div class="input-group mb-3" style="width:250px">\
  <span class="input-group-text" id="basic-addon1">Equivalent of 1€</span>\
    <input type="text" class="form-control valcur alpcur" placeholder="Ex : 1.50" aria-label="Username" aria-describedby="basic-addon1">\
  </div>\
  <button type="button" class="btn btn-primary addcur">Add</button>\
  </ul>\
</div>Currency</th><th> The equivalent of : 1 €</th></tr><thead><tbody></tbody></table>');
  $('.modal').modal('show');

  $('input.valcur').off('keypress').on('keypress', function(e){if(keypressfunc(e,this)==false){return false}});



// add a new currency

  $('.addcur').off('click').on('click',function(e){
      e.stopPropagation();
      $('input.alpcur').removeClass('is-invalid');
      ripi=0;
      $('.alpcur').each(function(e){

        if(!$(this).val() || ($(this).hasClass('namcur') && window.curr.hasOwnProperty(($(this).val()).toUpperCase())) || ($(this).hasClass('valcur') && (pattern.test($(this).val()) || pattern2.test($(this).val()) || pattern3.test($(this).val()) || pattern4.test($(this).val()))))
        {
          $(this).addClass('is-invalid');
        }else {
          ripi+=1;
        }
});
if(ripi==2)
{
  window.curr[($('.namcur').val()).toUpperCase()]=parseFloat($('.valcur').val());
  $('.currency').click();

}else {
  alert('Please check input value');
}
  });


/**************************************************************/

  $('.curtab tbody').html('');
  pps=1;
  for (var x in window.curr) {
if(x!='EUR')
{
    $('.curtab tbody').append('<tr><td><b>'+pps+'</b></td><td >'+x+'</td><td><input class="'+x+' cxra" type="text" value="'+window.curr[x]+'"></td></tr>')
pps++;
  }}

// disable presskey at any not number (only float an int number ) character by input

  $('.curtab input.cxra').off('keypress').on('keypress', function(e){if(keypressfunc(e,this)==false){return false}});

  // enable button of save change
$('.curtab input.cxra').on('input', function(e){
  $('.solva').prop('disabled',false);
});

// "save change" button click Function

$('.solva').off('click').on('click', function(e){

  $('.curtab input').each(function( index ) {

    valo=$(this).val();
    if(pattern.test($(this).val()))
    {
      valo=$(this).val()+'00';
    }
    if(pattern3.test($(this).val()))
    {
      valo='0'+$(this).val();
    }
    if(pattern2.test($(this).val()) || pattern4.test($(this).val()) || $(this).val()=='' || $(this).val()==0)
    {

      valo=1;
    }


    window.curr[$( this ).attr('class')]=valo;
    //alert('yess')
  });
  //alert(JSON.stringify(window.curr));
$('.modal').modal('hide');
});


});

// function when modal appear on screen

$('.modal').on('shown.bs.modal', function () {

$('.solva').prop('disabled',true);
  $('.closo').click(function(){
    $('.modal').modal('hide');
  });
})


/***********************************************************************************/
// On click for "commission processing " button

$('.comcalc').click(function(){


$('.dropda1').attr('vrd',1);
// charge data to json
for (var v in window.result) {


  if(window.result[v].length>6)
  {cura=window.result[v][9];
    vcura=window.result[v][8];}
    else {
      window.result[v][8]=window.result[v][4];
      window.result[v][9]=window.result[v][5];
      cura=window.result[v][5];
      vcura=window.result[v][4];
    }

  datetime=new Date(window.result[v][0]);
window.result[v][0]=datetime.getTime();
window.result[v][6]=affday('first',datetime);
window.result[v][7]=affday('last',datetime);




if(cura!=$('.dropda0').html())
{


bix=parseFloat(vcura)/parseFloat(window.curr[cura]);

window.result[v][4]=Math.round((parseFloat(bix)*parseFloat(window.curr[$('.dropda0').html()]))*100)/100

window.result[v][5]=$('.dropda0').html();
}
else {
  window.result[v][4]=vcura
  window.result[v][5]=cura;
}
}



// call to server by ajax

$.ajaxSetup({
headers: {
  'X-CSRF-TOKEN': $('.csrf').val()
       }
     });


$.ajax({
  type:'POST',
  url:'/proc',
  data:{'data':window.result,'param':window.param},
  beforeSend: function() {
    $('.export').hide();
    $('.outt .load').show();
  },
  complete: function() {
    $('.export').show();
        $('.outt .load').hide();
      },
  success:function(data) {
window.csv=data.act;
resulto=$('<span></span>');
for(var d in data.act)
{
resulto.append('<tr><td>'+data.act[d]+'</td></tr>');

}
  $('.outt').html('<table class="table">'+resulto.html()+'</table>');
  }

});



});

/***********************************************************************************/
// "export csv file" button

$('.export').click(function(){


var hiddenElement = document.createElement('a');
   hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(window.csv.join(","));
   hiddenElement.target = '_blank';
   hiddenElement.download = 'ProcessResults.csv';
   hiddenElement.click();

});




});



</script>



    </body>
</html>
